'''
DAY 5, QUESTION 2
COUNT THE NO OF DIGITS WHOSE FACTORIAL IS DIVISIBLE BY 2
'''
num=int(input("enter a number:"))
temp=num
count=0 

def factorial(num):
    if num==0 or num==1:
        return 1 
    else:
        return num*factorial(num-1)
        
while(temp>0):
    digit=temp%10
    if(factorial(digit)%2==0):
        count=count+1
    temp=temp//10

print(count)    
# if we want to find without using factorial then also we can find,
#as all the factorialof digits greater then 1 is even     