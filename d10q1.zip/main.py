num=int(input("enter a number:"))
temp=num 
count=0

while(temp>0):
    digit=temp%10
    count=count+digit
    temp=temp//10

if(count%9==0):
    print("harshad number")
else:
    print("not a harshad number")