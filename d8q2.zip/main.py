num = int(input("Enter a number: "))
temp = num
count = 0
prime_digits = {2, 3, 5, 7}

while temp > 0:
    digit = temp % 10
    if digit in prime_digits:
        count += 1
    temp //= 10

print("Number of prime digits:", count)