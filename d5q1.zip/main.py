'''
DAY 5, QUESTION 1 
CHECK WHETHER A NUMBER IS SPY OR NOT
'''
num=int(input("enter an= number:"))
temp=num
multiple_count=1
addition_count=0

while(temp>0):
    digit=temp%10
    multiple_count=multiple_count*digit
    addition_count=addition_count+digit
    temp=temp//10
    
if(multiple_count==addition_count):
    print("number is spy")
else:
    print("number is not spy")