num=int(input("enter a number:"))
temp=num 

while(temp>0):
    digit=temp%10
    if num%digit==0:
        print(digit)
    temp=temp//10
        