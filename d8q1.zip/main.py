num=int(input("enter a number"))
temp=num 

square=temp*temp
temp2=square
count=0
while(temp2>0):
    digit=temp2 % 10
    count=count+digit
    temp2=temp2//10
    
if(count==num):
    print("neon number")
else:
    print("not a neon number")