num=int(input("enter a number:"))
temp=num
count=0
def fibonnaci(num):
    if num==0 or num==1:
        return 1 
    else:
        return num*fibonnaci(num-1)

while(temp>0):
    digit=temp%10
    has=fibonnaci(digit)
    count=count+has
    temp=temp//10

if(count==num):
    print("strong number")
else:
    print("not a strong number")
        